package com.example.exam25.model.entity.enums;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
