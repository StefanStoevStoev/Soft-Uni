package com.example.exam25.model.view;

import com.example.exam25.model.entity.enums.StyleEnum;

import java.math.BigDecimal;

public class SongsViewModel {
    private Long id;
    private String performer;
    private String title;
    private int duration;
    private StyleEnum style;

    public SongsViewModel() {
    }

    public Long getId() {
        return id;
    }

    public SongsViewModel setId(Long id) {
        this.id = id;
        return this;
    }

    public String getPerformer() {
        return performer;
    }

    public SongsViewModel setPerformer(String performer) {
        this.performer = performer;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public SongsViewModel setTitle(String title) {
        this.title = title;
        return this;
    }

    public int getDuration() {
        return duration;
    }

    public SongsViewModel setDuration(int duration) {
        this.duration = duration;
        return this;
    }

    public StyleEnum getStyle() {
        return style;
    }

    public SongsViewModel setStyle(StyleEnum style) {
        this.style = style;
        return this;
    }
}
