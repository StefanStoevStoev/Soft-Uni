package com.example.exam25.web;

import com.example.exam25.model.DTO.SongDTO;
import com.example.exam25.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class SongsController {

    private final SongService songService;
    private final HttpSession httpSession;

    public SongsController(SongService songService, HttpSession httpSession) {
        this.songService = songService;
        this.httpSession = httpSession;
    }

    @GetMapping("add")
    public String addSong(){
        if (this.httpSession.getAttribute("name") != null) {
            return "home";
        }
        return "song-add";
    }

    @PostMapping("add")
    public String addSong1(@Valid SongDTO songDTO,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors() || !this.songService.addSong(songDTO)) {
            redirectAttributes.addFlashAttribute("songDTO", songDTO);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.songDTO", bindingResult);
            return "redirect:add";
        }
        return "redirect:home";
    }

    @ModelAttribute("songDTO")
    private SongDTO initForm(){
        return new SongDTO();
    }
}
