package com.example.exam25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam25Application {

    public static void main(String[] args) {
        SpringApplication.run(Exam25Application.class, args);
    }

}
