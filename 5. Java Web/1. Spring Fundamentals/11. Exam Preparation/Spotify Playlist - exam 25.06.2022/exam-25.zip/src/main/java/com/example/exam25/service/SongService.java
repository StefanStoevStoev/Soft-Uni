package com.example.exam25.service;

import com.example.exam25.model.DTO.SongDTO;
import com.example.exam25.model.entity.SongEntity;
import com.example.exam25.model.entity.StyleEntity;
import com.example.exam25.model.view.SongsViewModel;
import com.example.exam25.repository.SongRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SongService {

    private final SongRepository songRepository;
    private final StyleService styleService;
    private final ModelMapper modelMapper;

    public SongService(SongRepository songRepository, StyleService styleService, ModelMapper modelMapper) {
        this.songRepository = songRepository;
        this.styleService = styleService;
        this.modelMapper = modelMapper;
    }

    public boolean addSong(SongDTO songDTO) {

        SongEntity song = modelMapper.map(songDTO, SongEntity.class);

        StyleEntity styleEntity = this.styleService.
                findStyleByName(songDTO.getStyle()).orElseThrow(() ->
                        new IllegalArgumentException(String.format("Song %s not found",
                                songDTO.getStyle())));

        song.setStyle(styleEntity);

        songRepository.save(song);
        return true;
    }

    public List<SongsViewModel> findAllSongs() {
        return this.songRepository.findAll().stream().map(order -> modelMapper.map(order, SongsViewModel.class))
                .collect(Collectors.toList());
    }

}
