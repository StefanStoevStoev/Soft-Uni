package com.example.exam25.web;

import com.example.exam25.model.view.SongsViewModel;
import com.example.exam25.seasson.CurrentUser;
import com.example.exam25.service.SongService;
import com.example.exam25.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class HomeController {

    private final CurrentUser currentUser;
    private final ModelMapper modelMapper;
    private final UserService userService;
    private final SongService songService;

    public HomeController(CurrentUser currentUser, ModelMapper modelMapper, UserService userService, SongService songService) {
        this.currentUser = currentUser;
        this.modelMapper = modelMapper;
        this.userService = userService;
        this.songService = songService;
    }

    @GetMapping("/")
    public String indexLoggedOut() {
        return "index";
    }

    @GetMapping("/home")
    public String home(Model model) {

        if (currentUser.getId() == 0) {
            return "index";
        }

        List<SongsViewModel> songs = songService.findAllSongs();

        model.addAttribute("songs", songs);

        return "home";
    }

    @PostMapping("/home")
    public String homeAttack() {

        return "redirect:home";
    }

    @GetMapping("/logout")
    public String logout() {
        currentUser.logout();
        return "redirect:";
    }
}
