package CounterStriker.repositories;

import java.util.Collection;

import static CounterStriker.common.ExceptionMessages.INVALID_PLAYER_REPOSITORY;

public class GunRepository<Gun> implements Repository<Gun> {

    private Collection<Gun> models;
    private Gun gun;

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Gun model) {

    }

    @Override
    public boolean remove(Gun model) {
        return false;
    }

    public Gun findByName(String name) {
        return gun;
    }
}
