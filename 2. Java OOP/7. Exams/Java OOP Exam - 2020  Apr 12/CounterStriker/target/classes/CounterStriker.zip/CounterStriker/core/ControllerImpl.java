package CounterStriker.core;

import CounterStriker.models.field.Field;
import CounterStriker.models.guns.Gun;
import CounterStriker.models.guns.Pistol;
import CounterStriker.models.guns.Rifle;
import CounterStriker.models.players.CounterTerrorist;
import CounterStriker.models.players.Player;
import CounterStriker.models.players.Terrorist;

import java.util.HashMap;
import java.util.Map;

import static CounterStriker.common.ExceptionMessages.*;
import static CounterStriker.common.OutputMessages.SUCCESSFULLY_ADDED_GUN;
import static CounterStriker.common.OutputMessages.SUCCESSFULLY_ADDED_PLAYER;

public class ControllerImpl implements Controller {

    private Map<String,Gun> gunsMap;
    private Map<String,Player> playersMap;
    private Field field;

    public ControllerImpl() {
        this.gunsMap = new HashMap<>();
        this.playersMap = new HashMap<>();

    }

    @Override
    public String addGun(String type, String name, int bulletsCount) {

        if(!type.equals("Pistol")&&!type.equals("Rifle")){
            throw new IllegalArgumentException(INVALID_GUN_TYPE);
        }

        Gun gunRepository;

        if (type.equals("Pistol")){
            gunRepository = new Pistol(name,bulletsCount);
        }else {
            gunRepository = new Rifle(name,bulletsCount);

        }

        gunsMap.put(name, gunRepository);

        return String.format(SUCCESSFULLY_ADDED_GUN,name);
    }

    @Override
    public String addPlayer(String type, String username, int health, int armor, String gunName) {
        if(!type.equals("Terrorist")&&!type.equals("CounterTerrorist")){
            throw new IllegalArgumentException(INVALID_PLAYER_TYPE);
        }
        if(!gunsMap.containsKey(gunName)){
            throw new NullPointerException(GUN_CANNOT_BE_FOUND);
        }
        Player player;

        if (type.equals("Terrorist")){
            player = new Terrorist(username,health,armor,gunsMap.get(gunName));
        }else {
            player = new CounterTerrorist(username,health,armor,gunsMap.get(gunName));

        }

        playersMap.put(username, player);

        return String.format(SUCCESSFULLY_ADDED_PLAYER,username);
    }

    @Override
    public String startGame() {
        return null;
    }

    @Override
    public String report() {
        return null;
    }
}
