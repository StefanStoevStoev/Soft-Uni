package CounterStriker.repositories;

import java.util.Collection;

public class PlayerRepository<Player> implements Repository<Player> {

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Player model) {
    }

    @Override
    public boolean remove(Player model) {
        return false;
    }

    @Override
    public Player findByName(String name) {
        return null;
    }
}
