package com.example.android_visuals2

import android.graphics.drawable.Drawable
import android.graphics.drawable.TransitionDrawable
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.android_visuals2.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private var count = 0
    lateinit var binding: ActivityMainBinding

    private val images = arrayOf(
        R.drawable.img1,
        R.drawable.img2,
        R.drawable.img3,
        R.drawable.img4,
        R.drawable.img5,
        R.drawable.img6,
        R.drawable.img7,
        R.drawable.img8,
        R.drawable.img9,
        R.drawable.img10
    )
    private val names = arrayOf(
        "img1", "img2", "img3", "img4", "img5", "img6", "img7", "img8", "img9", "img10"
        )

    override fun onCreate(savedInstanceState: Bundle?) {

        var editText = ""

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rndImage = names.get(0)
        binding.button.setOnClickListener { view ->
            count++
            val rnd = images.random()

            val firstName = images.get(0)

            var index = rnd - firstName

            binding.imageView.setImageResource(rnd)


//            setImageDrawableWithAnimation(binding.imageView )
            binding.rndImage = names.get(index)
            Snackbar.make(view, editText, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            binding.textView.text = editText

        }
    }
//    fun setImageDrawableWithAnimation(
//        imageView: ImageView,
//        drawable: Drawable?,
//        duration: Int,
//    ) {
//        val currentDrawable = imageView.drawable
//        if (currentDrawable == null) {
//            imageView.setImageDrawable(drawable)
//            return
//        }
//        val transitionDrawable = TransitionDrawable(arrayOf(
//            currentDrawable,
//            drawable
//        ))
//        imageView.setImageDrawable(transitionDrawable)
//        transitionDrawable.startTransition(duration)
//    }
}