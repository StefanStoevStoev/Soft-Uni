import java.util.*

//Initial arrays:
val a = arrayOf(2, 3, 4, 5, 6, 12, 13, 14, 15)
var b = arrayOf(0, 2, 4, 6, 10, 11, 12, 13)
val c = (0..20).toList().toTypedArray()
var d = arrayOf<Int>()

//Created the first function:
var firstFun = { number: Int -> a.filter { p -> p == number } }

//Created second function:
fun secondFun(number: Int, arrParam: Array<Int>): Array<Int> {
    arrParam.forEach { num ->
        if (num != 0 && number % num == 0) {
            d += num
        }
    }
    return d
}
//Created main function:
fun mainFunction(n: Int, fiFunc: List<Int>, secFun: Array<Int>) {
    if (n % 3 == 0) {
        if (fiFunc.equals("[]")) println("PASSED NUMBER -> NO") else println("PASSED NUMBER -> YES")

//Avoiding empty array of DIVISORS:
    } else if(!secFun.isEmpty()){
        d = arrayOf()
        val secondFun = Arrays.toString(secondFun(n, b))
        println("PASSED NUMBER -> DIVISORS $secondFun")
    }
}

//Condition to check with all numbers of array "c":
for (numb in c) {
    mainFunction(numb, firstFun(numb), secondFun(numb, b))

//Clear data from "d" array:
    d = arrayOf()
}

//No information which files to save. All folder is too big, that's why I can send only the scratch file.
