import kotlin.math.PI

//Find circumference and surface of a circle with:
val r = 12.775

//If "r" means radius of a circle:

val circumference = r * 2 * PI
circumference

val surface = PI * Math.pow(r, 2.0)
surface


