//Problem 1.

val a = 5
val b = 6.25
val c = 4.5
val d = 5.5
val h = 3.825

val perimeter = a + b + c + d
perimeter

//If we accept that bases are "b" and "d"
val surface = (b + d) * h / 2
surface

