import java.util.*

val listIterator = listOf(2..100).flatMap { it }
var oddListIterator = listIterator.filter { it % 2 != 0 }.toTypedArray()
listIterator
Arrays.toString(oddListIterator)

var counterPrime = 0
var counterOdd = 0
var counterEven = 0
/* IndexOfList represent divisible numbers wich have to separate prime numbers
 from odd numbers. I use only odd numbers because we cannot divide odd by even
  number without reminder.
  I divide listIterator by 6 because 2*3 = 6 => 2 because we need only odd
  numbers, 3 is because we don need more than 1/3 from odd numbers for division
   to insulate which is prime number, we don't need to loop more numbers than
   needed.
   listIterator.size - 4, because I want to insulate 35 of "indexOfList",
    we dont need 33, because 35 * 3 = 105, we dont have 105 number of the
     initial array list.
 */
val indexOfList = (listIterator.size - 4) / 6
println(indexOfList)
var secondList = oddListIterator.slice(1..indexOfList)
println(secondList)

//My program accept the fact, that all of prime numbers are and odds too.
for (currentNumber in listIterator) {
    if (currentNumber % 2 == 0) {
        counterEven += currentNumber
        if(currentNumber == 2){
            counterPrime += currentNumber
        }
    } else {
        if (currentNumber % 3 == 0) {
            counterOdd += currentNumber
            if (currentNumber == 3) {
                counterPrime += currentNumber
            }
        } else {
            counterOdd += currentNumber
            var boolVar = true;
            for (number in secondList) {
                if (currentNumber <= number) {
                    break
                } else if (currentNumber % number == 0) {
                    boolVar = false
                    break
                }
            }
            if (boolVar) {
                counterPrime += currentNumber
            }
        }
    }
}
counterEven
counterOdd
counterPrime



